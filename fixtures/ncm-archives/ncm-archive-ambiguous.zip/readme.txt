Mixed export runs (fixture). Not a config.
