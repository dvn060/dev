Exported from SolarWinds NCM (fixture). Not a config.
